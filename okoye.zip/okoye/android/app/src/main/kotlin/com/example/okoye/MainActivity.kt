package com.example.okoye

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
